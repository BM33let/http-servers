﻿namespace MiniServer.HTTP
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}
