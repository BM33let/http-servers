﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MiniServer.HTTP.Enums
{
    public enum HttpRequestMethod
    {
        Get,
        Post,
        Put,
        Delete
    }
}
